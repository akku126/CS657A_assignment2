This is a cleaned version of the IIIT-H Word Similarity database. It fixes some format issues with some files. 

Original database: https://github.com/syedsarfarazakhtar/Word-Similarity-Datasets-for-Indian-Languages



